import { Routes, Route } from 'react-router'
import { AuthProvider } from './contexts/AuthContext'
import { UserDataProvider } from './contexts/UserDataContext'
import Layout from './components/Layout'
import Home from './pages/Home'
import Practice from './pages/Practice'
import WrongBook from './pages/WrongBook'
import Stats from './pages/Stats'
import MemoryMode from './pages/MemoryMode'
import SimExam from './pages/SimExam'
import Login from './pages/Login'
import Admin from './pages/Admin'

export default function App() {
  return (
    <AuthProvider>
      <UserDataProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/sim-exam" element={<SimExam />} />
          <Route path="*" element={
            <Layout>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/practice" element={<Practice />} />
                <Route path="/wrongbook" element={<WrongBook />} />
                <Route path="/stats" element={<Stats />} />
                <Route path="/memory" element={<MemoryMode />} />
              </Routes>
            </Layout>
          } />
        </Routes>
      </UserDataProvider>
    </AuthProvider>
  )
}
