import { createContext, useState, useCallback, useEffect, type ReactNode } from 'react';
import type { User, AuthState, UserData } from '@/types';

const AUTH_STATE_KEY = 'pymaster_current_user';
const USERS_KEY = 'pymaster_users';

interface AuthContextType {
  authState: AuthState;
  login: (studentId: string, password: string) => User;
  register: (studentId: string, name: string, password: string) => User;
  logout: () => void;
  isAdmin: () => boolean;
  getCurrentUser: () => User | null;
  getAllUsers: () => User[];
  getUserData: (userId: string) => UserData;
  saveUserData: (userId: string, data: UserData) => void;
}

export const AuthContext = createContext<AuthContextType | null>(null);

function getUsers(): User[] {
  try {
    const raw = localStorage.getItem(USERS_KEY);
    return raw ? (JSON.parse(raw) as User[]) : [];
  } catch {
    return [];
  }
}

function saveUsers(users: User[]) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function getAuthState(): AuthState {
  try {
    const raw = localStorage.getItem(AUTH_STATE_KEY);
    if (raw) {
      const user = JSON.parse(raw) as User;
      return { user, isLoggedIn: true };
    }
  } catch { /* empty */ }
  return { user: null, isLoggedIn: false };
}

function initDefaultAdmin() {
  const users = getUsers();
  const adminExists = users.some((u) => u.studentId === 'admin');
  if (!adminExists) {
    const adminUser: User = {
      id: 'admin-default',
      studentId: 'admin',
      name: '管理员',
      password: 'admin123',
      role: 'admin',
      createdAt: new Date().toISOString(),
    };
    saveUsers([...users, adminUser]);
  }
}

const defaultUserData = (userId: string): UserData => ({
  userId,
  wrongAnswers: [],
  studyStats: {
    totalAnswered: 0,
    totalCorrect: 0,
    correctRate: 0,
    streakDays: 0,
    lastStudyDate: '',
    byType: [
      { type: 'single', answered: 0, correct: 0 },
      { type: 'fill', answered: 0, correct: 0 },
      { type: 'codeFill', answered: 0, correct: 0 },
      { type: 'codeFix', answered: 0, correct: 0 },
    ],
    byCategory: [],
    dailyActivity: [],
    weakAreas: [],
  },
  memoryStatus: {},
  examHistory: [],
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>(getAuthState);

  // Initialize default admin on first mount
  useEffect(() => {
    initDefaultAdmin();
  }, []);

  const login = useCallback((studentId: string, password: string): User => {
    const users = getUsers();
    const user = users.find((u) => u.studentId === studentId && u.password === password);
    if (!user) {
      throw new Error('学号或密码错误');
    }
    const state: AuthState = { user, isLoggedIn: true };
    setAuthState(state);
    localStorage.setItem(AUTH_STATE_KEY, JSON.stringify(user));
    return user;
  }, []);

  const register = useCallback((studentId: string, name: string, password: string): User => {
    const users = getUsers();
    if (users.some((u) => u.studentId === studentId)) {
      throw new Error('该学号已被注册');
    }
    if (studentId.length < 3) {
      throw new Error('学号至少需要3位字符');
    }
    if (password.length < 6) {
      throw new Error('密码至少需要6位字符');
    }
    const newUser: User = {
      id: `user_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      studentId,
      name,
      password,
      role: 'student',
      createdAt: new Date().toISOString(),
    };
    saveUsers([...users, newUser]);
    // Auto login after register
    const state: AuthState = { user: newUser, isLoggedIn: true };
    setAuthState(state);
    localStorage.setItem(AUTH_STATE_KEY, JSON.stringify(newUser));
    // Initialize user data storage
    const userDataKey = `pymaster_userdata_${newUser.id}`;
    localStorage.setItem(userDataKey, JSON.stringify(defaultUserData(newUser.id)));
    return newUser;
  }, []);

  const logout = useCallback(() => {
    setAuthState({ user: null, isLoggedIn: false });
    localStorage.removeItem(AUTH_STATE_KEY);
  }, []);

  const isAdmin = useCallback((): boolean => {
    return authState.user?.role === 'admin';
  }, [authState.user]);

  const getCurrentUser = useCallback((): User | null => {
    return authState.user;
  }, [authState.user]);

  const getAllUsers = useCallback((): User[] => {
    return getUsers().filter((u) => u.role === 'student');
  }, []);

  const getUserData = useCallback((userId: string): UserData => {
    try {
      const raw = localStorage.getItem(`pymaster_userdata_${userId}`);
      if (raw) {
        return JSON.parse(raw) as UserData;
      }
    } catch { /* empty */ }
    return defaultUserData(userId);
  }, []);

  const saveUserData = useCallback((userId: string, data: UserData) => {
    localStorage.setItem(`pymaster_userdata_${userId}`, JSON.stringify(data));
  }, []);

  return (
    <AuthContext.Provider
      value={{
        authState,
        login,
        register,
        logout,
        isAdmin,
        getCurrentUser,
        getAllUsers,
        getUserData,
        saveUserData,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
