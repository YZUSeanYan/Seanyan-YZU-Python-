import { NavLink } from 'react-router';
import { motion } from 'framer-motion';
import { PythonLogo } from './SvgAssets';

const quickLinks = [
  { to: '/', label: '首页' },
  { to: '/practice', label: '练习' },
  { to: '/exam', label: '模拟考试' },
  { to: '/wrongbook', label: '错题本' },
  { to: '/stats', label: '学习统计' },
];

export default function Footer() {
  return (
    <motion.footer
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      className="w-full bg-pm-bg-dark"
    >
      <div className="max-w-[1200px] mx-auto px-6 pt-12 pb-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10 mb-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <PythonLogo className="w-7 h-7" />
              <span className="font-heading font-semibold text-lg text-white">SeanYan</span>
            </div>
            <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.6)' }}>
              SeanYan — 让 Python 备考更高效
            </p>
            <p className="text-xs mt-2" style={{ color: 'rgba(255,255,255,0.4)' }}>
              精选 547 道题目，覆盖四大题型
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading font-semibold text-sm text-white mb-3 tracking-wide uppercase" style={{ letterSpacing: '0.05em' }}>
              快速链接
            </h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.to}>
                  <NavLink
                    to={link.to}
                    className="text-sm transition-colors hover:text-white"
                    style={{ color: 'rgba(255,255,255,0.6)' }}
                  >
                    {link.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>

          {/* Question Bank Info */}
          <div>
            <h4 className="font-heading font-semibold text-sm text-white mb-3 tracking-wide uppercase" style={{ letterSpacing: '0.05em' }}>
              题库信息
            </h4>
            <div className="space-y-2 text-sm" style={{ color: 'rgba(255,255,255,0.6)' }}>
              <p>题目总数：<span className="text-white font-medium">547 题</span></p>
              <p>单选题：120 题</p>
              <p>填空题：40 题</p>
              <p>程序填空题：39 题</p>
              <p>程序改错题：10 题</p>
              <p className="text-xs mt-3" style={{ color: 'rgba(255,255,255,0.4)' }}>
                最后更新：2026-06-17
              </p>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="pt-6 border-t border-white/10 text-center text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>
          &copy; 2026 SeanYan. All rights reserved.
        </div>
      </div>
    </motion.footer>
  );
}
