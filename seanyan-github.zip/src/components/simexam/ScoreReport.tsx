import { motion } from 'framer-motion';
import { Trophy, RotateCcw, Home, CheckCircle, XCircle, HelpCircle, Clock, Target, TrendingUp } from 'lucide-react';
import { useNavigate } from 'react-router';
import type { QuestionType } from '@/types';
import type { Question } from '@/types';

interface ExamSection {
  type: QuestionType;
  label: string;
  count: number;
  questions: Question[];
}

interface ScoreReportProps {
  score: number;
  correctCount: number;
  totalQuestions: number;
  answeredCount: number;
  sections: ExamSection[];
  answers: Record<number, string>;
  timeSpent: number;
  onRestart: () => void;
}

export default function ScoreReport({ score, correctCount, totalQuestions, answeredCount, sections, answers, timeSpent, onRestart }: ScoreReportProps) {
  const navigate = useNavigate();

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) return `${h}小时${m}分${s}秒`;
    return `${m}分${s}秒`;
  };

  // Calculate section stats
  const sectionStats = sections.map((section) => {
    let sectionCorrect = 0;
    let sectionAnswered = 0;
    section.questions.forEach((q) => {
      const ans = answers[q.id];
      if (ans) {
        sectionAnswered++;
        const correctAnswer = Array.isArray(q.answer) ? q.answer[0] : q.answer;
        if (ans === correctAnswer) sectionCorrect++;
      }
    });
    return {
      ...section,
      correct: sectionCorrect,
      answered: sectionAnswered,
      rate: section.questions.length > 0 ? Math.round((sectionCorrect / section.questions.length) * 100) : 0,
    };
  });

  const getScoreGrade = () => {
    if (score >= 90) return { label: '优秀', color: '#27AE60', bg: '#E8F8EF' };
    if (score >= 80) return { label: '良好', color: '#0F4C81', bg: '#E8F1F8' };
    if (score >= 70) return { label: '中等', color: '#E9A23B', bg: '#FDF3E0' };
    if (score >= 60) return { label: '及格', color: '#E9A23B', bg: '#FDF3E0' };
    return { label: '不及格', color: '#E74C3C', bg: '#FDEDEC' };
  };

  const grade = getScoreGrade();

  return (
    <div className="min-h-[100dvh] bg-[#F5F7FA] pt-4 pb-12">
      <div className="max-w-[800px] mx-auto px-4">
        {/* Header Card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="bg-white rounded-xl shadow-pm-lg overflow-hidden mb-6"
        >
          {/* Top Banner */}
          <div className="bg-gradient-to-r from-[#0F4C81] to-[#1A6BAF] px-6 py-6 text-center">
            <Trophy className="w-10 h-10 text-[#E9A23B] mx-auto mb-2" />
            <h1 className="text-[22px] font-bold text-white mb-1">考试结束</h1>
            <p className="text-[13px] text-white/70">Python期末考试模拟 — 成绩报告</p>
          </div>

          {/* Score Circle */}
          <div className="flex flex-col items-center py-8">
            <div className="relative mb-4">
              <svg width="160" height="160" viewBox="0 0 160 160">
                <circle cx="80" cy="80" r="70" fill="none" stroke="#E2E8F0" strokeWidth="10" />
                <motion.circle
                  cx="80"
                  cy="80"
                  r="70"
                  fill="none"
                  stroke={grade.color}
                  strokeWidth="10"
                  strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 70}`}
                  initial={{ strokeDashoffset: 2 * Math.PI * 70 }}
                  animate={{ strokeDashoffset: 2 * Math.PI * 70 * (1 - score / 100) }}
                  transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
                  transform="rotate(-90 80 80)"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <motion.span
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.8, delay: 0.3 }}
                  className="text-[36px] font-bold"
                  style={{ color: grade.color }}
                >
                  {score}
                </motion.span>
                <span className="text-[12px] text-pm-text-muted">分</span>
              </div>
            </div>

            {/* Grade Badge */}
            <span
              className="px-4 py-1 rounded-full text-[14px] font-semibold"
              style={{ color: grade.color, backgroundColor: grade.bg }}
            >
              {grade.label}
            </span>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-4 gap-4 px-6 pb-6">
            <div className="text-center p-3 bg-[#F5F7FA] rounded-lg">
              <CheckCircle className="w-5 h-5 text-[#27AE60] mx-auto mb-1" />
              <p className="text-[18px] font-bold text-pm-text-primary">{correctCount}</p>
              <p className="text-[11px] text-pm-text-muted">答对题数</p>
            </div>
            <div className="text-center p-3 bg-[#F5F7FA] rounded-lg">
              <XCircle className="w-5 h-5 text-[#E74C3C] mx-auto mb-1" />
              <p className="text-[18px] font-bold text-pm-text-primary">{answeredCount - correctCount}</p>
              <p className="text-[11px] text-pm-text-muted">答错题数</p>
            </div>
            <div className="text-center p-3 bg-[#F5F7FA] rounded-lg">
              <HelpCircle className="w-5 h-5 text-[#94A3B8] mx-auto mb-1" />
              <p className="text-[18px] font-bold text-pm-text-primary">{totalQuestions - answeredCount}</p>
              <p className="text-[11px] text-pm-text-muted">未答题数</p>
            </div>
            <div className="text-center p-3 bg-[#F5F7FA] rounded-lg">
              <Clock className="w-5 h-5 text-[#0F4C81] mx-auto mb-1" />
              <p className="text-[18px] font-bold text-pm-text-primary">{formatTime(timeSpent)}</p>
              <p className="text-[11px] text-pm-text-muted">用时</p>
            </div>
          </div>
        </motion.div>

        {/* Section Breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="bg-white rounded-xl shadow-pm-md p-6 mb-6"
        >
          <h2 className="text-[16px] font-semibold text-pm-text-primary mb-4 flex items-center gap-2">
            <Target className="w-5 h-5 text-[#0F4C81]" />
            各题型得分
          </h2>
          <div className="space-y-4">
            {sectionStats.map((stat, idx) => (
              <motion.div
                key={stat.type}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: 0.3 + idx * 0.1 }}
                className="flex items-center gap-4"
              >
                <div className="w-[100px] shrink-0">
                  <p className="text-[13px] font-medium text-pm-text-primary">{stat.label}</p>
                  <p className="text-[11px] text-pm-text-muted">共{stat.count}题</p>
                </div>
                <div className="flex-1">
                  <div className="h-2 bg-[#F0F0F0] rounded-full overflow-hidden">
                    <motion.div
                      className="h-full rounded-full"
                      style={{ backgroundColor: stat.rate >= 60 ? '#27AE60' : '#E74C3C' }}
                      initial={{ width: 0 }}
                      animate={{ width: `${stat.rate}%` }}
                      transition={{ duration: 0.8, delay: 0.4 + idx * 0.1, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
                    />
                  </div>
                </div>
                <div className="w-[80px] text-right shrink-0">
                  <p className="text-[13px] font-semibold" style={{ color: stat.rate >= 60 ? '#27AE60' : '#E74C3C' }}>
                    {stat.correct}/{stat.count}
                  </p>
                  <p className="text-[11px] text-pm-text-muted">{stat.rate}%</p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Total Accuracy */}
          <div className="mt-5 pt-4 border-t border-[#E2E8F0] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-[#0F4C81]" />
              <span className="text-[14px] font-medium text-pm-text-primary">总体正确率</span>
            </div>
            <span className="text-[20px] font-bold text-[#0F4C81]">
              {totalQuestions > 0 ? Math.round((correctCount / totalQuestions) * 100) : 0}%
            </span>
          </div>
        </motion.div>

        {/* Answer Review */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="bg-white rounded-xl shadow-pm-md p-6 mb-6"
        >
          <h2 className="text-[16px] font-semibold text-pm-text-primary mb-4">答题详情</h2>
          <div className="space-y-3 max-h-[400px] overflow-y-auto">
            {sections.map((section) =>
              section.questions.map((q) => {
                const ans = answers[q.id];
                const correctAnswer = Array.isArray(q.answer) ? q.answer[0] : q.answer;
                const isCorrect = ans === correctAnswer;
                const isAnswered = ans !== undefined && ans !== '';

                return (
                  <div key={q.id} className="flex items-start gap-3 p-3 rounded-lg bg-[#F5F7FA]">
                    <div className="shrink-0 mt-0.5">
                      {isAnswered ? (
                        isCorrect ? (
                          <CheckCircle className="w-4 h-4 text-[#27AE60]" />
                        ) : (
                          <XCircle className="w-4 h-4 text-[#E74C3C]" />
                        )
                      ) : (
                        <HelpCircle className="w-4 h-4 text-[#94A3B8]" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[13px] text-pm-text-primary truncate">
                        <span className="font-medium">{q.content.slice(0, 60)}...</span>
                      </p>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="text-[11px] text-pm-text-muted">
                          你的答案：{isAnswered ? (ans.length > 30 ? ans.slice(0, 30) + '...' : ans) : '未作答'}
                        </span>
                        {!isCorrect && (
                          <span className="text-[11px] text-[#27AE60]">
                            正确答案：{typeof correctAnswer === 'string' && correctAnswer.length > 30 ? correctAnswer.slice(0, 30) + '...' : correctAnswer}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="flex items-center justify-center gap-4"
        >
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={onRestart}
            className="flex items-center gap-2 bg-[#0F4C81] text-white font-medium px-6 py-2.5 rounded-lg hover:bg-[#0D3F6B] transition-colors shadow-pm-primary"
          >
            <RotateCcw className="w-4 h-4" />
            重新考试
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => navigate('/')}
            className="flex items-center gap-2 bg-white text-pm-text-primary font-medium px-6 py-2.5 rounded-lg border border-[#E2E8F0] hover:bg-[#F5F7FA] transition-colors"
          >
            <Home className="w-4 h-4" />
            返回首页
          </motion.button>
        </motion.div>
      </div>
    </div>
  );
}
