import { motion } from 'framer-motion';

interface ExamHeaderProps {
  seatNumber: string;
}

export default function ExamHeader({ seatNumber }: ExamHeaderProps) {
  return (
    <motion.div
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      className="h-[50px] bg-[#E8E8E8] flex items-center justify-between px-6 shrink-0 border-b border-[#D4D4D4]"
    >
      <h1 className="text-[16px] font-semibold text-pm-text-primary tracking-wide">
        Python期末考试模拟
      </h1>
      <div className="flex items-center gap-2">
        <span className="text-[13px] text-pm-text-secondary">座位号</span>
        <span className="text-[28px] font-bold text-[#CC0000] leading-none">{seatNumber}</span>
      </div>
    </motion.div>
  );
}
