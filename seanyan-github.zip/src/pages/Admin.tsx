import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Users,
  BookOpen,
  Trophy,
  Activity,
  ChevronRight,
  Search,
  BarChart3,
  UserCircle,
  ArrowLeft,
  Shield,
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import type { User, UserData, ExamRecord } from '@/types';

type AdminTab = 'overview' | 'users' | 'exams';

export default function Admin() {
  const navigate = useNavigate();
  const { authState, isAdmin, getAllUsers, getUserData } = useAuth();
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  // Redirect non-admin
  useEffect(() => {
    if (!authState.isLoggedIn || !isAdmin()) {
      navigate('/');
    }
  }, [authState.isLoggedIn, isAdmin, navigate]);

  const allUsers = useMemo(() => getAllUsers(), [getAllUsers]);

  const allUserData = useMemo(() => {
    const data: Record<string, UserData> = {};
    allUsers.forEach((u) => {
      data[u.id] = getUserData(u.id);
    });
    return data;
  }, [allUsers, getUserData]);

  const filteredUsers = useMemo(() => {
    if (!searchQuery.trim()) return allUsers;
    const q = searchQuery.toLowerCase();
    return allUsers.filter(
      (u) =>
        u.studentId.toLowerCase().includes(q) ||
        u.name.toLowerCase().includes(q)
    );
  }, [allUsers, searchQuery]);

  // Stats
  const stats = useMemo(() => {
    const totalUsers = allUsers.length;
    const today = new Date().toISOString().split('T')[0];
    const todayActive = allUsers.filter((u) => {
      const ud = allUserData[u.id];
      return ud?.studyStats?.dailyActivity?.some((d) => d.date === today);
    }).length;
    const totalAnswered = allUsers.reduce(
      (sum, u) => sum + (allUserData[u.id]?.studyStats?.totalAnswered || 0),
      0
    );
    const totalExams = allUsers.reduce(
      (sum, u) => sum + (allUserData[u.id]?.examHistory?.length || 0),
      0
    );
    return { totalUsers, todayActive, totalAnswered, totalExams };
  }, [allUsers, allUserData]);

  // All exam records
  const allExamRecords = useMemo(() => {
    const records: (ExamRecord & { studentName: string; studentId: string })[] = [];
    allUsers.forEach((u) => {
      const exams = allUserData[u.id]?.examHistory || [];
      exams.forEach((e) => {
        records.push({
          ...e,
          studentName: u.name,
          studentId: u.studentId,
        });
      });
    });
    return records.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [allUsers, allUserData]);

  const filteredExams = useMemo(() => {
    if (!searchQuery.trim()) return allExamRecords;
    const q = searchQuery.toLowerCase();
    return allExamRecords.filter(
      (e) =>
        e.studentId.toLowerCase().includes(q) ||
        e.studentName.toLowerCase().includes(q) ||
        e.date.includes(q)
    );
  }, [allExamRecords, searchQuery]);

  const recentUsers = useMemo(() => {
    return [...allUsers]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 10);
  }, [allUsers]);

  const handleViewUserDetail = (user: User) => {
    setSelectedUser(user);
    setActiveTab('users');
  };

  if (!authState.isLoggedIn || !isAdmin()) {
    return null;
  }

  const navItems: { key: AdminTab; label: string; icon: React.ReactNode }[] = [
    { key: 'overview', label: '概览', icon: <BarChart3 className="w-4 h-4" /> },
    { key: 'users', label: '用户管理', icon: <Users className="w-4 h-4" /> },
    { key: 'exams', label: '考试记录', icon: <Trophy className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-[100dvh] bg-pm-bg-primary">
      {/* Top bar */}
      <div className="bg-white border-b border-pm-border">
        <div className="max-w-[1400px] mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/')}
              className="flex items-center gap-1.5 text-sm text-pm-text-secondary hover:text-pm-primary transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-pm-primary" />
              <h1 className="font-heading font-semibold text-lg text-pm-text-primary">
                管理后台
              </h1>
            </div>
          </div>
          <div className="flex items-center gap-2 text-sm text-pm-text-secondary">
            <UserCircle className="w-4 h-4" />
            <span>{authState.user?.name}</span>
          </div>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar */}
          <div className="w-full lg:w-56 shrink-0">
            <div className="bg-white rounded-pm-lg border border-pm-border overflow-hidden">
              <nav className="p-2 space-y-1">
                {navItems.map((item) => (
                  <button
                    key={item.key}
                    onClick={() => {
                      setActiveTab(item.key);
                      if (item.key !== 'users') setSelectedUser(null);
                    }}
                    className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-pm-md text-sm font-medium transition-colors ${
                      activeTab === item.key
                        ? 'bg-pm-primary text-white'
                        : 'text-pm-text-secondary hover:bg-pm-bg-primary hover:text-pm-text-primary'
                    }`}
                  >
                    {item.icon}
                    {item.label}
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Main content */}
          <div className="flex-1 min-w-0">
            {/* Search bar */}
            <div className="mb-4">
              <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-pm-text-muted" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={
                    activeTab === 'users' ? '搜索学号或姓名...' : '搜索学号、姓名或日期...'
                  }
                  className="w-full pl-9 pr-4 py-2 rounded-pm-lg border border-pm-border bg-white text-sm text-pm-text-primary placeholder:text-pm-text-muted focus:outline-none focus:ring-2 focus:ring-pm-primary/20 focus:border-pm-primary transition-all"
                />
              </div>
            </div>

            <AnimatePresence mode="wait">
              {activeTab === 'overview' && (
                <motion.div
                  key="overview"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-6"
                >
                  {/* Stat cards */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <StatCard
                      icon={<Users className="w-5 h-5" />}
                      label="总注册学生"
                      value={stats.totalUsers}
                      color="primary"
                    />
                    <StatCard
                      icon={<Activity className="w-5 h-5" />}
                      label="今日活跃"
                      value={stats.todayActive}
                      color="accent"
                    />
                    <StatCard
                      icon={<BookOpen className="w-5 h-5" />}
                      label="总答题数"
                      value={stats.totalAnswered}
                      color="purple"
                    />
                    <StatCard
                      icon={<Trophy className="w-5 h-5" />}
                      label="总考试次数"
                      value={stats.totalExams}
                      color="orange"
                    />
                  </div>

                  {/* Recent users */}
                  <div className="bg-white rounded-pm-lg border border-pm-border overflow-hidden">
                    <div className="px-6 py-4 border-b border-pm-border flex items-center justify-between">
                      <h2 className="font-semibold text-pm-text-primary">最近注册学生</h2>
                      <button
                        onClick={() => setActiveTab('users')}
                        className="text-xs text-pm-primary hover:underline flex items-center gap-0.5"
                      >
                        查看全部 <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                    <div className="divide-y divide-pm-border">
                      {recentUsers.length === 0 ? (
                        <div className="px-6 py-8 text-center text-sm text-pm-text-muted">
                          暂无注册学生
                        </div>
                      ) : (
                        recentUsers.map((u) => {
                          const ud = allUserData[u.id];
                          return (
                            <div
                              key={u.id}
                              className="px-6 py-3 flex items-center justify-between hover:bg-pm-bg-primary/50 transition-colors"
                            >
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-pm-primary-light flex items-center justify-center">
                                  <span className="text-xs font-semibold text-pm-primary">
                                    {u.name.charAt(0)}
                                  </span>
                                </div>
                                <div>
                                  <p className="text-sm font-medium text-pm-text-primary">
                                    {u.name}
                                  </p>
                                  <p className="text-xs text-pm-text-muted">
                                    {u.studentId}
                                  </p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="text-xs text-pm-text-secondary">
                                  答题: {ud?.studyStats?.totalAnswered || 0}
                                </p>
                                <p className="text-xs text-pm-text-muted">
                                  正确率: {ud?.studyStats?.correctRate || 0}%
                                </p>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'users' && (
                <motion.div
                  key="users"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                >
                  {selectedUser ? (
                    <UserDetailPanel
                      user={selectedUser}
                      userData={allUserData[selectedUser.id]}
                      onBack={() => setSelectedUser(null)}
                    />
                  ) : (
                    <div className="bg-white rounded-pm-lg border border-pm-border overflow-hidden">
                      <div className="px-6 py-4 border-b border-pm-border">
                        <h2 className="font-semibold text-pm-text-primary">
                          学生列表（{filteredUsers.length}人）
                        </h2>
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead>
                            <tr className="border-b border-pm-border bg-pm-bg-primary/50">
                              <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                                学号
                              </th>
                              <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                                姓名
                              </th>
                              <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                                注册时间
                              </th>
                              <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                                答题数
                              </th>
                              <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                                正确率
                              </th>
                              <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                                操作
                              </th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-pm-border">
                            {filteredUsers.length === 0 ? (
                              <tr>
                                <td
                                  colSpan={6}
                                  className="px-4 py-8 text-center text-sm text-pm-text-muted"
                                >
                                  未找到匹配的学生
                                </td>
                              </tr>
                            ) : (
                              filteredUsers.map((u) => {
                                const ud = allUserData[u.id];
                                return (
                                  <tr
                                    key={u.id}
                                    className="hover:bg-pm-bg-primary/30 transition-colors"
                                  >
                                    <td className="px-4 py-3 text-sm text-pm-text-primary font-mono">
                                      {u.studentId}
                                    </td>
                                    <td className="px-4 py-3 text-sm text-pm-text-primary font-medium">
                                      {u.name}
                                    </td>
                                    <td className="px-4 py-3 text-sm text-pm-text-secondary">
                                      {new Date(u.createdAt).toLocaleDateString('zh-CN')}
                                    </td>
                                    <td className="px-4 py-3 text-sm text-pm-text-secondary">
                                      {ud?.studyStats?.totalAnswered || 0}
                                    </td>
                                    <td className="px-4 py-3">
                                      <span
                                        className={`inline-flex px-2 py-0.5 rounded-pm-full text-xs font-medium ${
                                          (ud?.studyStats?.correctRate || 0) >= 60
                                            ? 'bg-pm-success-light text-pm-success'
                                            : 'bg-pm-error-light text-pm-error'
                                        }`}
                                      >
                                        {ud?.studyStats?.correctRate || 0}%
                                      </span>
                                    </td>
                                    <td className="px-4 py-3">
                                      <button
                                        onClick={() => handleViewUserDetail(u)}
                                        className="text-xs text-pm-primary hover:underline font-medium"
                                      >
                                        查看详情
                                      </button>
                                    </td>
                                  </tr>
                                );
                              })
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </motion.div>
              )}

              {activeTab === 'exams' && (
                <motion.div
                  key="exams"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="bg-white rounded-pm-lg border border-pm-border overflow-hidden">
                    <div className="px-6 py-4 border-b border-pm-border">
                      <h2 className="font-semibold text-pm-text-primary">
                        考试记录（{filteredExams.length}条）
                      </h2>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b border-pm-border bg-pm-bg-primary/50">
                            <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                              学号
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                              姓名
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                              日期
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                              得分
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                              正确/总数
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                              用时
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-pm-border">
                          {filteredExams.length === 0 ? (
                            <tr>
                              <td
                                colSpan={6}
                                className="px-4 py-8 text-center text-sm text-pm-text-muted"
                              >
                                暂无考试记录
                              </td>
                            </tr>
                          ) : (
                            filteredExams.map((e) => (
                              <tr
                                key={e.id}
                                className="hover:bg-pm-bg-primary/30 transition-colors"
                              >
                                <td className="px-4 py-3 text-sm text-pm-text-primary font-mono">
                                  {e.studentId}
                                </td>
                                <td className="px-4 py-3 text-sm text-pm-text-primary font-medium">
                                  {e.studentName}
                                </td>
                                <td className="px-4 py-3 text-sm text-pm-text-secondary">
                                  {new Date(e.date).toLocaleString('zh-CN')}
                                </td>
                                <td className="px-4 py-3">
                                  <span
                                    className={`inline-flex px-2 py-0.5 rounded-pm-full text-xs font-semibold ${
                                      e.score >= 60
                                        ? 'bg-pm-success-light text-pm-success'
                                        : 'bg-pm-error-light text-pm-error'
                                    }`}
                                  >
                                    {e.score}分
                                  </span>
                                </td>
                                <td className="px-4 py-3 text-sm text-pm-text-secondary">
                                  {e.correctCount}/{e.totalQuestions}
                                </td>
                                <td className="px-4 py-3 text-sm text-pm-text-secondary">
                                  {Math.floor(e.timeSpent / 60)}分{e.timeSpent % 60}秒
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============ Sub Components ============

function StatCard({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  color: 'primary' | 'accent' | 'purple' | 'orange';
}) {
  const colorMap = {
    primary: {
      bg: 'bg-pm-primary-light',
      text: 'text-pm-primary',
    },
    accent: {
      bg: 'bg-pm-accent-light',
      text: 'text-pm-accent',
    },
    purple: {
      bg: 'bg-pm-purple-light',
      text: 'text-pm-purple',
    },
    orange: {
      bg: 'bg-pm-orange-light',
      text: 'text-pm-orange',
    },
  };

  const c = colorMap[color];

  return (
    <div className="bg-white rounded-pm-lg border border-pm-border p-4">
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-pm-md ${c.bg} flex items-center justify-center ${c.text}`}>
          {icon}
        </div>
        <div>
          <p className="text-xs text-pm-text-muted">{label}</p>
          <p className="text-xl font-bold text-pm-text-primary font-heading">{value}</p>
        </div>
      </div>
    </div>
  );
}

function UserDetailPanel({
  user,
  userData,
  onBack,
}: {
  user: User;
  userData: UserData;
  onBack: () => void;
}) {
  return (
    <div className="space-y-4">
      <button
        onClick={onBack}
        className="text-sm text-pm-primary hover:underline flex items-center gap-1"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        返回列表
      </button>

      {/* User info card */}
      <div className="bg-white rounded-pm-lg border border-pm-border p-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-pm-primary-light flex items-center justify-center">
            <span className="text-lg font-bold text-pm-primary">{user.name.charAt(0)}</span>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-pm-text-primary">{user.name}</h3>
            <p className="text-sm text-pm-text-secondary">
              学号: {user.studentId} | 注册: {new Date(user.createdAt).toLocaleDateString('zh-CN')}
            </p>
          </div>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-pm-lg border border-pm-border p-4">
          <p className="text-xs text-pm-text-muted">总答题数</p>
          <p className="text-xl font-bold text-pm-text-primary font-heading">
            {userData?.studyStats?.totalAnswered || 0}
          </p>
        </div>
        <div className="bg-white rounded-pm-lg border border-pm-border p-4">
          <p className="text-xs text-pm-text-muted">正确率</p>
          <p className="text-xl font-bold text-pm-text-primary font-heading">
            {userData?.studyStats?.correctRate || 0}%
          </p>
        </div>
        <div className="bg-white rounded-pm-lg border border-pm-border p-4">
          <p className="text-xs text-pm-text-muted">连续学习</p>
          <p className="text-xl font-bold text-pm-text-primary font-heading">
            {userData?.studyStats?.streakDays || 0} 天
          </p>
        </div>
        <div className="bg-white rounded-pm-lg border border-pm-border p-4">
          <p className="text-xs text-pm-text-muted">考试次数</p>
          <p className="text-xl font-bold text-pm-text-primary font-heading">
            {userData?.examHistory?.length || 0}
          </p>
        </div>
      </div>

      {/* Exam history */}
      <div className="bg-white rounded-pm-lg border border-pm-border overflow-hidden">
        <div className="px-6 py-4 border-b border-pm-border">
          <h3 className="font-semibold text-pm-text-primary">考试历史</h3>
        </div>
        {(userData?.examHistory?.length || 0) === 0 ? (
          <div className="px-6 py-8 text-center text-sm text-pm-text-muted">暂无考试记录</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-pm-border bg-pm-bg-primary/50">
                  <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                    日期
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                    得分
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                    正确/总数
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-pm-text-muted uppercase tracking-wider">
                    用时
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-pm-border">
                {userData?.examHistory?.map((e) => (
                  <tr key={e.id}>
                    <td className="px-4 py-3 text-sm text-pm-text-secondary">
                      {new Date(e.date).toLocaleString('zh-CN')}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex px-2 py-0.5 rounded-pm-full text-xs font-semibold ${
                          e.score >= 60
                            ? 'bg-pm-success-light text-pm-success'
                            : 'bg-pm-error-light text-pm-error'
                        }`}
                      >
                        {e.score}分
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-pm-text-secondary">
                      {e.correctCount}/{e.totalQuestions}
                    </td>
                    <td className="px-4 py-3 text-sm text-pm-text-secondary">
                      {Math.floor(e.timeSpent / 60)}分{e.timeSpent % 60}秒
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
