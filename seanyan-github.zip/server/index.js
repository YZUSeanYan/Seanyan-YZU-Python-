import express from 'express';
import cors from 'cors';
import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3456;
const HOST = process.env.HOST || '0.0.0.0';

// Middleware
app.use(cors());
app.use(express.json());

// Ensure data directory exists
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

// Initialize SQLite database
const db = new Database(path.join(dataDir, 'seanyan.db'));

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    student_id TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    password TEXT NOT NULL,
    role TEXT DEFAULT 'student',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS user_data (
    user_id TEXT PRIMARY KEY,
    wrong_answers TEXT DEFAULT '[]',
    study_stats TEXT DEFAULT '{}',
    memory_status TEXT DEFAULT '{}',
    exam_history TEXT DEFAULT '[]',
    practice_progress TEXT DEFAULT '{}',
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
`);

// Migrate: add practice_progress column if table exists without it
try {
  db.exec(`ALTER TABLE user_data ADD COLUMN practice_progress TEXT DEFAULT '{}'`);
} catch { /* column already exists, ignore */ }

// Prepared statements
const stmts = {
  createUser: db.prepare('INSERT INTO users (id, student_id, name, password, role, created_at) VALUES (?, ?, ?, ?, ?, ?)'),
  findUserByStudentId: db.prepare('SELECT * FROM users WHERE student_id = ?'),
  findUserById: db.prepare('SELECT * FROM users WHERE id = ?'),
  getAllUsers: db.prepare("SELECT id, student_id, name, role, created_at FROM users WHERE role IN ('student', 'admin') ORDER BY created_at DESC"),
  updateUserPassword: db.prepare('UPDATE users SET password = ? WHERE student_id = ?'),
  getUserData: db.prepare('SELECT * FROM user_data WHERE user_id = ?'),
  upsertUserData: db.prepare(`
    INSERT INTO user_data (user_id, wrong_answers, study_stats, memory_status, exam_history, practice_progress, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(user_id) DO UPDATE SET
      wrong_answers = excluded.wrong_answers,
      study_stats = excluded.study_stats,
      memory_status = excluded.memory_status,
      exam_history = excluded.exam_history,
      practice_progress = excluded.practice_progress,
      updated_at = excluded.updated_at
  `),
};

// Ensure admin exists
function ensureAdmin() {
  const admin = stmts.findUserByStudentId.get('admin');
  if (!admin) {
    stmts.createUser.run(
      'admin-default', 'admin', '管理员', 'sb董瀚扬', 'admin',
      new Date().toISOString()
    );
    console.log('[DB] Admin user created: admin / sb董瀚扬');
  } else {
    stmts.updateUserPassword.run('sb董瀚扬', 'admin');
    console.log('[DB] Admin password ensured');
  }
}
ensureAdmin();

// ===== API Routes =====

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', mode: 'server', time: new Date().toISOString() });
});

// Register
app.post('/api/register', (req, res) => {
  try {
    const { studentId, name, password } = req.body;
    if (!studentId || !name || !password) {
      return res.status(400).json({ error: '学号、姓名和密码不能为空' });
    }
    if (studentId.length < 2) {
      return res.status(400).json({ error: '学号至少2个字符' });
    }
    if (password.length < 4) {
      return res.status(400).json({ error: '密码至少4个字符' });
    }

    const existing = stmts.findUserByStudentId.get(studentId);
    if (existing) {
      return res.status(409).json({ error: '该学号已被注册' });
    }

    const id = 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
    stmts.createUser.run(id, studentId, name, password, 'student', new Date().toISOString());

    const user = stmts.findUserByStudentId.get(studentId);
    res.json({
      success: true,
      user: { id: user.id, studentId: user.student_id, name: user.name, role: user.role }
    });
  } catch (err) {
    console.error('[Register Error]', err);
    res.status(500).json({ error: '注册失败' });
  }
});

// Login
app.post('/api/login', (req, res) => {
  try {
    const { studentId, password } = req.body;
    if (!studentId || !password) {
      return res.status(400).json({ error: '学号和密码不能为空' });
    }

    const user = stmts.findUserByStudentId.get(studentId);
    if (!user) {
      return res.status(401).json({ error: '学号或密码错误' });
    }
    if (user.password !== password) {
      return res.status(401).json({ error: '学号或密码错误' });
    }

    res.json({
      success: true,
      user: { id: user.id, studentId: user.student_id, name: user.name, role: user.role }
    });
  } catch (err) {
    console.error('[Login Error]', err);
    res.status(500).json({ error: '登录失败' });
  }
});

// Get all users (admin only)
app.get('/api/users', (req, res) => {
  try {
    const rows = stmts.getAllUsers.all();
    const users = rows.map((u) => ({
      id: u.id,
      studentId: u.student_id,
      name: u.name,
      role: u.role,
      createdAt: u.created_at,
    }));
    res.json({ users });
  } catch (err) {
    console.error('[Users Error]', err);
    res.status(500).json({ error: '获取用户列表失败' });
  }
});

// Get user data
app.get('/api/userdata/:userId', (req, res) => {
  try {
    const data = stmts.getUserData.get(req.params.userId);
    if (!data) {
      return res.json({
        wrong_answers: '[]',
        study_stats: '{}',
        memory_status: '{}',
        exam_history: '[]',
        practice_progress: '{}'
      });
    }
    res.json({
      wrong_answers: data.wrong_answers,
      study_stats: data.study_stats,
      memory_status: data.memory_status,
      exam_history: data.exam_history,
      practice_progress: data.practice_progress
    });
  } catch (err) {
    console.error('[UserData Error]', err);
    res.status(500).json({ error: '获取用户数据失败' });
  }
});

// Save user data
app.post('/api/userdata/:userId', (req, res) => {
  try {
    const { wrong_answers, study_stats, memory_status, exam_history, practice_progress } = req.body;
    stmts.upsertUserData.run(
      req.params.userId,
      JSON.stringify(wrong_answers || []),
      JSON.stringify(study_stats || {}),
      JSON.stringify(memory_status || {}),
      JSON.stringify(exam_history || []),
      JSON.stringify(practice_progress || {}),
      new Date().toISOString()
    );
    res.json({ success: true });
  } catch (err) {
    console.error('[SaveUserData Error]', err);
    res.status(500).json({ error: '保存用户数据失败' });
  }
});

// ===== Serve Frontend =====

const distPath = path.join(__dirname, '..', 'dist');
if (fs.existsSync(distPath)) {
  // Static files
  app.use(express.static(distPath));
  // SPA fallback - must be after API routes
  app.get(/.*/, (req, res) => {
    if (!req.path.startsWith('/api/')) {
      res.sendFile(path.join(distPath, 'index.html'));
    }
  });
}

// Start server
app.listen(PORT, HOST, () => {
  console.log(`[Server] SeanYan backend running on http://${HOST}:${PORT}`);
  console.log(`[Server] API: http://${HOST}:${PORT}/api/`);
  if (fs.existsSync(distPath)) {
    console.log(`[Server] Frontend: http://${HOST}:${PORT}/`);
  }
  console.log(`[Server] Admin: admin / sb董瀚扬`);
  console.log('');
  console.log('>>> 让其他设备访问:');
  console.log('    1. 确保你的防火墙允许端口 ' + PORT);
  console.log('    2. 其他设备用你电脑的IP地址访问');
  console.log('    3. 例如: http://192.168.1.5:' + PORT);
  console.log('');
});
